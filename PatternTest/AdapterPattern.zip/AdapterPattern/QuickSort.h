//
// Created by weiguow on 18-10-26.
//

#ifndef STUDENTSMANAGE_QUICKSORT_H
#define STUDENTSMANAGE_QUICKSORT_H

#include <iostream>
#include <vector>

using std::vector;

class QuickSort{
public:
    void quicksort(vector<int> &vec, int low, int high);
};
#endif //STUDENTSMANAGE_QUICKSORT_H
