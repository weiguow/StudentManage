//
// Created by weiguow on 18-10-25.
//

#ifndef STUDENTSMANAGE_BINARYSEARCH_H
#define STUDENTSMANAGE_BINARYSEARCH_H

#include <iostream>
#include <array>
#include <string>
#include <vector>

using std::string;
using std::vector;

class BinarySearch{
public:
    int binarysearch(vector<int> &invec, int &pos, int &value);
};
#endif //STUDENTSMANAGE_BINARYSEARCH_H
